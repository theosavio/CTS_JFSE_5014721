public interface ExcelDocument {
    void open();
    void close();
    void save();
}
