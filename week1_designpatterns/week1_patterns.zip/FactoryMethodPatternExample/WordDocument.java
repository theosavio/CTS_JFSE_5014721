
public interface WordDocument {

	
	void open();
	void close();
	void save();
	}
