public interface PdfDocument {
    void open();
    void close();
    void save();
}
